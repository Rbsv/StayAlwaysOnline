# *Stay Always Online*
# *NEW UPDATES*
-> includies mouse movements

# *Description*
this app lets you stay online even when you are not using your system, simply just enable the app and let it run in the background, this app is made publically free,  also at the same time I would not suggest this  to use every time. your organization pays you to get your task done. please use this responsibly and don't misuse this app. 

Supports:

**->Skype** 

**->Ms teams**

**->Discord**

**->Slack**

or any other apps that look for keyboard inputs.

Made with Love From India.
